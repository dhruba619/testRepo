package com.test.ConfigTest.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.test.ConfigTest.bo.TestBo;
import com.test.ConfigTest.model.Test;

@RestController
@RequestMapping("/")
public class TestController {
	
	@Autowired
	private TestBo testBo;
	
	public ResponseEntity<Map<String, Object>> createUpdate(Test test) {
		HttpStatus statuss = HttpStatus.INTERNAL_SERVER_ERROR;
		Map<String, Object> rsMap = new HashMap<>();
		try {
			rsMap = testBo.saveUpdate(test);
			if (!rsMap.get("message").equals("Failed")) {
				statuss = HttpStatus.OK;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<Map<String, Object>>(rsMap, statuss);
	}

	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public ResponseEntity<Map<String, Object>> create(@RequestBody Test test) {
		return createUpdate(test);
	}

	@RequestMapping(value = "/update", method = RequestMethod.PUT)
	public ResponseEntity<Map<String, Object>> update(@RequestBody Test test) {
		return createUpdate(test);
	}
	
	@RequestMapping(value="/all", method=RequestMethod.GET)
	public ResponseEntity<List<Test>> getAll() {
		HttpStatus test = HttpStatus.INTERNAL_SERVER_ERROR;
		List<Test> list = new ArrayList<>();
		try {
			list = testBo.findAll();
			test = HttpStatus.OK;
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return new ResponseEntity<List<Test>>(list, test);
	}
	
	@RequestMapping(value="/get/{id}", method=RequestMethod.GET)
	public ResponseEntity<Test> findById(@PathVariable("id") Long id) {
		HttpStatus test = HttpStatus.INTERNAL_SERVER_ERROR;
		Test s = new Test();
		try {
			s = testBo.findById(id);
			test = HttpStatus.OK;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<Test>(s, test);
	}
	
	@RequestMapping("/")
	public String hello() {
		return "<h2>Hello API</h2>";
	}
}
