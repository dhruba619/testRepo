package com.test.ConfigTest.dao;

import org.springframework.data.repository.CrudRepository;

import com.test.ConfigTest.model.Test;

public interface ITestDao extends CrudRepository<Test, Long>{

}
