package com.test.ConfigTest.bo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.ConfigTest.dao.ITestDao;
import com.test.ConfigTest.model.Test;

@Service
public class TestBo {
	
	@Autowired
	private ITestDao testDao;
	
	public Map<String, Object> saveUpdate(Test Test) {
		Test s = new Test();
		Map<String, Object> rsMap = new HashMap<>();
		rsMap.put("message", "Failed");
		try {

			s = testDao.save(Test);
			rsMap.put("Test", s);
			rsMap.put("message", "Success");

		} catch (Exception e) {
			e.printStackTrace();

		}
		return rsMap;
	}

	public Test findById(Long id) {
		Test s = new Test();
		try {
			s = testDao.findById(id).orElse(null);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return s;
	}
	
	public List<Test>  findAll(){
		List<Test> list=new ArrayList<>();
		try {
			list=(List<Test>) testDao.findAll();
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

}
